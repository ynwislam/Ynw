
import os
import yaml
import base64
import zlib
import aiofiles
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("مرحباً! أرسل لي ملف كونفيغ (HTTP Custom أو HTTP Injector) وسأقوم بتفكيكه.")

async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    file = await update.message.document.get_file()
    file_path = f"./{update.message.document.file_name}"
    await file.download_to_drive(file_path)

    try:
        if file_path.endswith((".yaml", ".hc")):
            async with aiofiles.open(file_path, "r", encoding="utf-8") as f:
                content = await f.read()
                config = yaml.safe_load(content)
                await update.message.reply_text(f"تفكيك HTTP Custom:\n{config}")
        elif file_path.endswith(".ehi"):
            async with aiofiles.open(file_path, "rb") as f:
                raw = await f.read()
                try:
                    decoded = base64.b64decode(raw)
                    decompressed = zlib.decompress(decoded)
                    await update.message.reply_text(f"تفكيك HTTP Injector:\n{decompressed.decode('utf-8')}")
                except Exception as e:
                    await update.message.reply_text(f"خطأ أثناء التفكيك: {e}")
        else:
            await update.message.reply_text("نوع الملف غير مدعوم.")
    finally:
        os.remove(file_path)

if __name__ == "__main__":
    TOKEN = os.getenv("BOT_TOKEN")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_file))
    app.run_polling()
